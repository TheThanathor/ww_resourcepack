#version 460
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

// new
vec2[] corners = vec2[](
    vec2(1.0, 0.0),
    vec2(1.0, 1.0),
    vec2(0.0, 1.0),
    vec2(0.0, 0.0)
);
// default

void main() {
#ifdef IS_GUI
    // new
    vec3 newPosition = Position;
    float id = floor((newPosition.y + 1000.0) / 2000.0);
    newPosition.y = mod(newPosition.y + 1000.0, 2000.0) - 1000.0;

    gl_Position = ProjMat * ModelViewMat * vec4(newPosition, 1.0);

    bool marker = (Color.r * 255 == 249 && Color.g * 255 == 252 && Color.b * 255 == 247);
    if (marker) {
        gl_Position.xy += gl_Position.w * vec2(1,2);
    }
    vertexColor = marker ? vec4(1) : Color;
    if (id >= 4.0 && id <= 5.0) {
        vec2 corner = vec2(
            fract(UV0.x * 16.0) > 0.5 ? 1.0 : 0.0,
            fract(UV0.y * 16.0) > 0.5 ? 1.0 : 0.0
        );
        vec2 scaled = (corner * 2.0 - 1.0);
        scaled.y = -scaled.y;
        gl_Position = vec4(scaled * gl_Position.w, gl_Position.z, gl_Position.w);
    }
    else if (id == 1.0) {
        gl_Position.xy += gl_Position.w * vec2(-1, 0);
    }
    // default
#else
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
#if !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
#endif

// new
#if defined(RENDERPEARL_INSTANCE_INDEX_INCLUDES_BASE_INSTANCE)
    if ((Color.r * 255 == 255 && Color.g * 255 == 170 && Color.b * 255 == 4) || 
            (Color.r * 255 == 170 && Color.g * 255 == 170 && Color.b * 255 == 174) || 
            (Color.r * 255 == 85 && Color.g * 255 == 85 && Color.b * 255 == 89) || 
            (Color.r * 255 == 63 && Color.g * 255 == 42 && Color.b * 255 == 1) || 
            (Color.r * 255 == 42 && Color.g * 255 == 42 && Color.b * 255 == 43) || 
            (Color.r * 255 == 21 && Color.g * 255 == 21 && Color.b * 255 == 22)) {
        vertexColor = vec4(0);
    }
#endif
// default

    texCoord0 = UV0;
}
