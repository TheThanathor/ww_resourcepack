#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:light.glsl>
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
layout(location = 3) in ivec2 UV1;
layout(location = 4) in ivec2 UV2;
#ifdef GLINT_SPECIAL
layout(location = 5) in vec2 UV3;
#endif
layout(location = 6) in vec3 Normal;

#ifndef OIT_ALPHA_ONLY
uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif
layout(location = 2) out vec4 vertexColor;
#ifndef OIT_ALPHA_ONLY
layout(location = 3) out vec4 lightMapColor;
layout(location = 4) out vec4 overlayColor;
#endif

layout(location = 5) out vec2 texCoord0;
#ifdef GLINT
layout(location = 6) out vec2 texCoordGlint;
#endif

// new
bool shouldShade(vec4 color) {
    return abs(color.r * 255.0 - 1) < 0.5 &&
        abs(color.g * 255.0 - 1) < 0.5 &&
        abs(color.b * 255.0 - 254) < 0.5;
}

// 26.3 reversed-Z projection: near/far plane at 1/0 depth
#ifdef RENDERPEARL_DEPTH_IS_ZERO_TO_ONE
#define FAR_PLANE_NDC 0.0
#else
#define FAR_PLANE_NDC -1.0
#endif
// default

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    // new
    if (ProjMat[2][3] != 0.0) { // perspective only
        float farPlaneDist = gl_Position.z - FAR_PLANE_NDC * gl_Position.w;
        gl_Position.z = max(farPlaneDist, ProjMat[3][2] * 0.5) + FAR_PLANE_NDC * gl_Position.w;
    }
    // default

#ifndef OIT_ALPHA_ONLY
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
#endif
    // new
    if(!shouldShade(Color)) {
        vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
    } else {
        vertexColor = vec4(1.0);
    }

    // default
#ifndef OIT_ALPHA_ONLY
    lightMapColor = sample_lightmap(Sampler2, UV2);
    overlayColor = texelFetch(Sampler1, UV1, 0);
#endif

    texCoord0 = UV0;
#ifdef GLINT
#ifdef GLINT_SPECIAL
    texCoordGlint = (TextureMat * vec4(UV3, 0.0, 1.0)).xy;
#else
    texCoordGlint = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif
#endif
}
