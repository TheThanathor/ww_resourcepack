#version 330

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

// new
uniform sampler2D Sampler0;
// default
uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#ifdef PER_FACE_LIGHTING
out vec4 vertexPerFaceColorBack;
out vec4 vertexPerFaceColorFront;
#else
out vec4 vertexColor;
#endif
out vec4 lightMapColor;
out vec4 overlayColor;
out vec2 texCoord0;
// new
out vec2 uv0;
out vec2 t;
// default

// new
int rgb2Int(vec4 color) {
    return (int(color.r * 255) << 16) + (int(color.g * 255) << 8) + int(color.b * 255);
}

int getVertId() {
#ifdef SODIUM_CORE_SHADER_SUPPORT
    int vid = gl_VertexID;
    switch ((vid / 4) % 6) {
        case 0:
        case 1:
        case 3:
        case 5:
            return vid;
        case 2:
            return vid + 8;
        case 4:
            return vid - 8;
    }
#else
    return gl_VertexID;
#endif
}
// default

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

#ifdef PER_FACE_LIGHTING
    vec2 light = minecraft_compute_light(Light0_Direction, Light1_Direction, Normal);
    vertexPerFaceColorBack = minecraft_mix_light_separate(-light, Color);
    vertexPerFaceColorFront = minecraft_mix_light_separate(light, Color);
#elif defined(NO_CARDINAL_LIGHTING)
    vertexColor = Color;
#else
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
#endif
#ifndef EMISSIVE
    lightMapColor = texelFetch(Sampler2, UV2 / 16, 0);
#endif
    overlayColor = texelFetch(Sampler1, UV1, 0);

    texCoord0 = UV0;
#ifdef APPLY_TEXTURE_MATRIX
    texCoord0 = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif

// new
uv0 = vec2(0);
t = vec2(0);
#ifdef PER_FACE_LIGHTING
    // Check color
    vec2 size = textureSize(Sampler0, 0); // Get texture size.
    vec4 gCorner = texture(Sampler0, vec2(0, 0)); // Global corner
    if ((gCorner.g * 255) == 254 && (gCorner.a * 255) == 254) {
        int layer = 254 - int(gCorner.b * 255);
        int slim = int(gCorner.r * 255) == 254 ? 1 : 0;
        int dead = int(gCorner.r * 255) == 253 ? 1 : 0;
        // Fix UV coordinates.
        int vertexID = getVertId() % 4;
        int faceID = (getVertId() / 4) % 42; // 0~5:head,right_arm,left_leg, 6~11:cap,left_arm,right_leg, 12~17:body
        vec2 d = getVertId() > 0 ? ivec2((((getVertId() - 1) % 4) / 2 * 2 - 1), ((getVertId() % 4) / 2 * 2 - 1)) : ivec2(1,-1); // Direction for expand.

        // vertexPerFaceColorFront = vec4(vertexID / 255.0, faceID / 255.0, 0, 1);

        uv0 = UV0 * vec2(64, 32); // Local pixel coordinates.
        texCoord0 = uv0 / size;

            // Get some parameters.
                // Flip direction
        if((faceID >= 6 && faceID < 8 && uv0.y >= 16)) {
            d.y *= -1;
        } // Where uv fliped (leg & arm).
        if((faceID >= 8 && faceID < 12 && uv0.y >= 20)) {
            d.y *= -1;
        } // Where uv fliped (leg & arm).
        if((faceID % 6) == 1) {
            d.y *= -1;
        } // Also where uv fliped (bottom of cube).
        if((uv0.x <= 16 && uv0.y >= 20) && ((faceID >= 2 && faceID < 6) || (faceID >= 8 && faceID < 12)) || (faceID >= 18 && faceID < 24)) {
            d.y *= -1;
        }
        if((uv0.x >= 4 && uv0.x <= 12 && uv0.y >= 16 && uv0.y <= 20) && ((faceID >= 0 && faceID < 2) || (faceID >= 6 && faceID < 8))) {
            d.y *= -1;
        } // All face of legs.
                // Set area
        vec2 _uv0 = uv0 - 0.5 * d; // px center pos.
        vec2 area = vec2(4.0, 12.0); // XY size of face.
        if(_uv0.y >= 0 && _uv0.y < 16) { // Head.
            area = vec2(8.0, 8.0);
        } else if(_uv0.y >= 16 && _uv0.y < 64) { // Body, Legs and arm.
            if(_uv0.y < 20) { // Top and bottom face.
                area.y = 4.0;
                if((_uv0.x >= 20 && _uv0.x < 36)) {
                    area.x = 8.0;
                    if (dead == 1) {
                        area.x = 14.0;
                        area.y = 6.0;
                    }
                } // Body top and bottom face.
                // else if (slim > 0 && _uv0.x >= 44) {
                //     area.x = 3.0;
                // } // arm top and bottom face.
            } else { // Front, back, and side face.
                if((_uv0.x >= 20 && _uv0.x < 28) || (_uv0.x >= 32 && _uv0.x < 40)) {
                    area.x = 8.0;
                    if (dead == 1) {
                        area.x = 14.0;
                        area.y = 24.0;
                    }
                } // Body front and back face.
                else {
                    if (dead == 1) {
                        area.x = 6.0;
                        area.y = 24.0;
                    }
                } // Body side face.
                // else if (slim > 0 && ((_uv0.x >= 44 && _uv0.x < 47) || (_uv0.x >= 51 && _uv0.x < 54))) {
                //     area.x = 3.0;
                // } // arm front and back face.
            }
        }

            // Resize constant.
        float a = 0.082;
        float b = 0.90;
        vec2 c = vec2(0.0, 0.0);
        vec2 e = vec2(0.0, 0.0);
        vec2 f = vec2(0.0, 0.0);
        if (slim > 0 && _uv0.x >= 40 && _uv0.y >= 16) { // slim arms
            if (faceID == 2 || faceID == 8) { // outer sides
                a = 0.175;
            }
            if (faceID == 4 || faceID == 10) { // inner sides
                a = 0.085;
                c.x = -1.0;
            }
            if (faceID == 0 || faceID == 3 || faceID == 6 || faceID == 9) { // top and front
                c.x = -1.0;
                e.x = -1.0;
                f.x = -0.333;
            }
            if (faceID == 1 || faceID == 7) { // bottom
                c.x = -2.0;
                e.x = -1.0;
                f.x = -0.333;
            }
            if (faceID == 5 || faceID == 11) { // back
                c.x = -1.0;
                e.x = -1.0;
                f.x = 0.333;
            }
        }
        if(layer > 0) {
            if (faceID < 36) { // overlay except head
                a *= 0.7;
                b *= 0.615;
                if (slim > 0 && (faceID == 2 || faceID == 8)) { // slim arms outer
                    a *= 1.355;
                }
            }
            else { // head overlay
                b *= 0.91;
            }
        }
        if(_uv0.x < 16 && _uv0.y >= 16) { // Boots
            a *= 0.85;
            b *= 0.83;
        }
        if (dead == 1) { 
            if (faceID < 12) { // arms
                // hide dead arms
                f.x = 10;
                f.y = 10;
            }
            if (faceID >= 18) { // legs
                // hide dead legs
                f.x = 10;
                f.y = 10;
            }
            if (faceID == 13) { // bottom
                a *= -1;
                c.x = 4.0;
                e.x = 2.0;
            }
            if (faceID == 14 || faceID == 16) { // sides
                a *= -1;
                c.x = 4.0;
                e.x = 2.0;
            }
            if (faceID == 15 || faceID == 17) { // front and back
                a *= -1;
                c.x = 4.0;
                e.x = 10.0;
            }
        }

        // Shrink model
        gl_Position = ProjMat * ModelViewMat * vec4(Position - Normal * a, 1.0); // 1. Move faces in a perpendicular direction to fit the surface and the body.
        texCoord0 = (uv0 + d * b + c) / size; // 2. Expand UV coordinates to match texture.


        t = d + (d * (b - e) * 2 / area) + f; // 3. Remove the overhang with a fragment shader.
        // vertexPerFaceColorFront = vec4(faceID == 1 ? 1 : 0);
        // vertexPerFaceColorFront = (layer > 0 && faceID >= 36) ? vec4(1) : vec4(0);
    }
#endif
// default

}
