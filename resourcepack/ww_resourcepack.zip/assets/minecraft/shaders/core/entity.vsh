#version 460
// new ^ (must be first line tho)

#if defined(PER_FACE_LIGHTING) || !defined(NO_CARDINAL_LIGHTING)
#include <minecraft:light.glsl>
#endif
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
layout(location = 3) in ivec2 UV1;
layout(location = 4) in ivec2 UV2;
layout(location = 5) in vec3 Normal;

// new
uniform sampler2D Sampler0;
// default

#if !defined(NO_OVERLAY) && !defined(OIT_ALPHA_ONLY)
uniform sampler2D Sampler1;
#endif

#if !defined(EMISSIVE) && !defined(OIT_ALPHA_ONLY)
uniform sampler2D Sampler2;
#endif

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;

#ifdef PER_FACE_LIGHTING
layout(location = 2) out vec4 vertexPerFaceColorBack;
layout(location = 3) out vec4 vertexPerFaceColorFront;
#else
layout(location = 2) out vec4 vertexColor;
#endif

#ifndef EMISSIVE
layout(location = 4) out vec4 lightMapColor;
#endif

#ifndef NO_OVERLAY
layout(location = 5) out vec4 overlayColor;
#endif

layout(location = 6) out vec2 texCoord0;
#ifdef GLINT
layout(location = 7) out vec2 texCoordGlint;
#endif

// new
layout(location = 8) out vec2 t; // must match entity.fsh
// default

// new
int rgb2Int(vec4 color) {
    return (int(color.r * 255) << 16) + (int(color.g * 255) << 8) + int(color.b * 255);
}

int getVertId() {
    float vid = gl_VertexIndex - gl_BaseVertex;

#ifdef SODIUM_CORE_SHADER_SUPPORT
    switch ((vid / 4) % 6) {
        case 0:
        case 1:
        case 3:
        case 5:
            return vid;
        case 2:
            return vid + 8;
        case 4:
            return vid - 8;
    }
#else
    return int(vid);
#endif
}

vec3 tangent = normalize(vec3(Normal.z, 0, -Normal.x));
vec3 bitangent = cross(Normal, tangent);
mat3 TBN = mat3(tangent, bitangent, Normal);
// default

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

#ifdef PER_FACE_LIGHTING
    vec2 light = minecraft_compute_light(Light0_Direction, Light1_Direction, Normal);
    vertexPerFaceColorBack = minecraft_mix_light_separate(-light, Color);
    vertexPerFaceColorFront = minecraft_mix_light_separate(light, Color);
#elif defined(NO_CARDINAL_LIGHTING)
    vertexColor = Color;
#else
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
#endif

#if !defined(EMISSIVE) && !defined(OIT_ALPHA_ONLY)
    lightMapColor = sample_lightmap(Sampler2, UV2);
#endif

#if !defined(NO_OVERLAY) && !defined(OIT_ALPHA_ONLY)
    overlayColor = texelFetch(Sampler1, UV1, 0);
#endif

    texCoord0 = UV0;

#ifdef APPLY_TEXTURE_MATRIX
    texCoord0 = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif

#ifdef GLINT
    texCoordGlint = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif

// new
vec2 uv0 = vec2(0);
t = vec2(0);
#ifdef PER_FACE_LIGHTING
    // Check color
    vec2 size = textureSize(Sampler0, 0); // Get texture size.
    vec4 gCorner = texture(Sampler0, vec2(0, 0)); // Global corner
    if ((gCorner.g * 255) == 254 && (gCorner.a * 255) == 254) {
        int layer = 254 - int(gCorner.b * 255);
        int slim = int(gCorner.r * 255) == 254 ? 1 : 0;
        int dead = int(gCorner.r * 255) == 253 ? 1 : 0;
        // Fix UV coordinates.
        int vertexID = getVertId() % 4;
        int faceID = (getVertId() / 4) % 30; // 0~5:head,right_arm,left_leg, 6~11:cap,left_arm,right_leg, 12~17:body
        vec2 d = getVertId() > 0 ? ivec2((((getVertId() - 1) % 4) / 2 * 2 - 1), ((getVertId() % 4) / 2 * 2 - 1)) : ivec2(1,-1); // Direction for expand.

        // vertexPerFaceColorFront = vec4(vertexID / 255.0, faceID / 255.0, 0, 1);

        uv0 = UV0 * vec2(64, 32); // Local pixel coordinates.

            // Get some parameters.
                // Flip direction
        if((faceID >= 6 && faceID < 8 && uv0.y >= 16)) {
            d.y *= -1;
        } // Where uv fliped (leg & arm).
        if((faceID >= 8 && faceID < 12 && uv0.y >= 20)) {
            d.y *= -1;
        } // Where uv fliped (leg & arm).
        if((faceID % 6) == 1) {
            d.y *= -1;
        } // Also where uv fliped (bottom of cube).
        if((uv0.x <= 16 && uv0.y >= 20) && ((faceID >= 2 && faceID < 6) || (faceID >= 8 && faceID < 12)) || (faceID >= 18 && faceID < 24)) {
            d.y *= -1;
        }
        if((uv0.x >= 4 && uv0.x <= 12 && uv0.y >= 16 && uv0.y <= 20) && ((faceID >= 0 && faceID < 2) || (faceID >= 6 && faceID < 8))) {
            d.y *= -1;
        } // All face of legs.
                // Set area
        vec2 _uv0 = uv0 - 0.5 * d; // px center pos.
        vec2 area = vec2(4.0, 12.0); // XY size of face.
        if(_uv0.y >= 0 && _uv0.y < 16) { // Head.
            area = vec2(8.0, 8.0);
        } else if(_uv0.y >= 16 && _uv0.y < 64) { // Body, Legs and arm.
            if(_uv0.y < 20) { // Top and bottom face.
                area.y = 4.0;
                if((_uv0.x >= 20 && _uv0.x < 36)) {
                    area.x = 8.0;
                    if (dead == 1) {
                        area.x = 14.0;
                        area.y = 6.0;
                    }
                } // Body top and bottom face.
                // else if (slim > 0 && _uv0.x >= 44) {
                //     area.x = 3.0;
                // } // arm top and bottom face.
            } else { // Front, back, and side face.
                if((_uv0.x >= 20 && _uv0.x < 28) || (_uv0.x >= 32 && _uv0.x < 40)) {
                    area.x = 8.0;
                    if (dead == 1) {
                        area.x = 14.0;
                        area.y = 24.0;
                    }
                } // Body front and back face.
                else {
                    if (dead == 1) {
                        area.x = 6.0;
                        area.y = 24.0;
                    }
                } // Body side face.
                // else if (slim > 0 && ((_uv0.x >= 44 && _uv0.x < 47) || (_uv0.x >= 51 && _uv0.x < 54))) {
                //     area.x = 3.0;
                // } // arm front and back face.
            }
        }

            // Resize constant.
        float a = 0.082;
        float b = 0.90;
        vec2 c = vec2(0.0, 0.0);
        vec2 e = vec2(0.0, 0.0);
        vec2 f = vec2(0.0, 0.0);
        vec3 m = vec3(0.0, 0.0, 0.0);
        mat3 s = mat3(vec3(0),vec3(0),vec3(0));
        if (slim > 0 && _uv0.x >= 40 && _uv0.y >= 16) { // slim arms
            if (faceID == 2 || faceID == 8) { // outer sides
                a = 0.175;
            }
            if (faceID == 4 || faceID == 10) { // inner sides
                a = 0.085;
                c.x = -1.0;
            }
            if (faceID == 0 || faceID == 3 || faceID == 6 || faceID == 9) { // top and front
                c.x = -1.0;
                e.x = -1.0;
                f.x = -0.333;
            }
            if (faceID == 1 || faceID == 7) { // bottom
                c.x = -2.0;
                e.x = -1.0;
                f.x = -0.333;
            }
            if (faceID == 5 || faceID == 11) { // back
                c.x = -1.0;
                e.x = -1.0;
                f.x = 0.333;
            }
        }
        if(layer > 0) {
            if (faceID < 36) { // overlay except head
                a *= 0.7;
                b *= 0.615;
                if (slim > 0 && (faceID == 2 || faceID == 8)) { // slim arms outer
                    a *= 1.355;
                }
            }
            else { // head overlay
                b *= 0.91;
            }
        }
        if(_uv0.x < 16 && _uv0.y >= 16) { // Boots
            a *= 0.85;
            b *= 0.83;
        }
        if (faceID < 12) { // arms
            // hide arms
            f.x = 10;
            f.y = 10;
        }
        if (dead == 1) { 
            vertexPerFaceColorBack = Color;
            vertexPerFaceColorFront = Color;
            s = TBN;
            if (faceID >= 18) { // legs
                // hide dead legs
                f.x = 10;
                f.y = 10;
            }
            if (faceID == 12 || faceID == 13) { // top and bottom
                // hide top and bottom body faces (they don't render with TBN set)
                f.x = 10;
                f.y = 10;
            }
            if (faceID == 14 || faceID == 16) { // sides
                // hide since their rotation doesn't work correctly
                f.x = 10;
                f.y = 10;
            }
            if (faceID == 15 || faceID == 17) { // front and back
                area = vec2(14, 24);
                if (layer == 0) { // inner
                    size = vec2(37.0, 17.0);
                    c = vec2(1.05, 0.05);
                    e = vec2(-0.6, -0.15);
                    a = 0.0;
                    b = 0.90;

                    if (faceID == 15) { // front
                        uv0 = uv0 - vec2(21.0, 15.45);
                    }
                    if (faceID == 17) { // back
                        uv0 = uv0 - vec2(21.45, 15.45); 
                    }
                }
                else if (layer == 1) { // outer
                    size = vec2(34.7, 16.3);
                    c = vec2(-0.46, 0.16);
                    e = vec2(-0.6, -0.1);
                    a = -0.05;
                    b = 0.24;

                    if (faceID == 15) { // front
                        uv0 = uv0 - vec2(19.75, 16.0);
                    }
                    if (faceID == 17) { // back
                        uv0 = uv0 - vec2(20.9, 16.0);
                    }
                }
                else if (layer == 2) { // extra layer for top face
                    size = vec2(34.7, 65.2);
                    c = vec2(-0.46, 0.16);
                    e = vec2(-0.6, 0.0);
                    a = -0.05;
                    b = 0.24;
                    area = vec2(14, 6);

                    if (faceID == 17) { // top
                        uv0 = uv0 - vec2(31.75, 16.0);
                    }
                    else {
                        f.x = 10;
                        f.y = 10;
                    }
                }
                else if (layer == 3) { // side inner layer
                    area = vec2(6, 24);
                    size = vec2(70.0, 17.0);
                    c = vec2(1.05, 0.05);
                    e = vec2(-0.6, -0.15);
                    a = 0.0;
                    b = 0.90;

                    if (faceID == 15) { // east
                        uv0 = uv0 - vec2(6.45, -1.55);
                    }
                    else if (faceID == 17) { // west
                        uv0 = uv0 - vec2(-3.4, -1.55);
                    }
                    else {
                        f.x = 10;
                        f.y = 10;
                    }
                }
                else if (layer == 4) { // side outer layer
                    area = vec2(6, 24);
                    size = vec2(71.0, 16.3);
                    c = vec2(-0.46, 0.16);
                    e = vec2(-0.6, -0.1);
                    a = -0.05;
                    b = 0.24;

                    if (faceID == 15) { // east
                        uv0 = uv0 - vec2(4.7, -0.3);
                    }
                    else if (faceID == 17) { // west
                        uv0 = uv0 - vec2(-5.5, -0.3);
                    }
                    else {
                        f.x = 10;
                        f.y = 10;
                    }
                }

// faceID == 14: Torso Right Side Face.
// faceID == 15: Torso Front Face.
// faceID == 16: Torso Left Side Face.
// faceID == 17: Torso Back Face
// 1 --- 0
// |     |
// 2 --- 3

                if (layer < 2) { // front & back
                    switch (vertexID) {
                    case 0:
                        m.x = 0.25;
                        m.y = 0.0;
                        break;
                    case 1:
                        m.x = -0.25;
                        m.y = 0.0;
                        break;
                    case 2:
                        m.x = -0.25;
                        m.y = -0.85;
                        break;
                    case 3:
                        m.x = 0.25;
                        m.y = -0.85;
                        break;
                    }
                }
                else if (layer == 2) { // top face
                    if (faceID == 17) {
                        switch (vertexID) {
                        case 0:
                            m.x = 0.19825;  m.y = -0.0835;  m.z = -0.603;
                            break;
                        case 1:
                            m.x = -0.19825;   m.y = -0.0835;  m.z = -0.603;
                            break;
                        case 2:
                            m.x = -0.19825;   m.y = 1.1545;  m.z = -0.028;
                            break;
                        case 3:
                            m.x = 0.19825;  m.y = 1.1545;  m.z = -0.028;
                            break;
                        }
                    }
                }
                else if (layer == 3) { // side inner layer
                    switch (vertexID) {
                        case 0:
                            m.x = -1.0078125;  m.y = 0.0;  m.z = 0.135;
                            break;
                        case 1:
                            m.x = -0.125;   m.y = 0.0;  m.z = -0.665;
                            break;
                        case 2:
                            m.x = -0.125;   m.y = -0.85;  m.z = -0.665;
                            break;
                        case 3:
                            m.x = -1.0078125;  m.y = -0.85;  m.z = 0.135;
                            break;
                        }
                }
                else if (layer == 4) { // side outer layer
                    switch (vertexID) {
                        case 0:
                            m.x = -1.055;  m.y = 0.0;  m.z = 0.09;
                            break;
                        case 1:
                            m.x = -0.1775;   m.y = 0.0;  m.z = -0.718;
                            break;
                        case 2:
                            m.x = -0.1775;   m.y = -0.85;  m.z = -0.718;
                            break;
                        case 3:
                            m.x = -1.055;  m.y = -0.85;  m.z = 0.09;
                            break;
                        }
                }
            }
        }

        // Shrink model
        gl_Position = ProjMat * ModelViewMat * vec4((Position - Normal * a) + (s * m), 1.0); // 1. Move faces in a perpendicular direction to fit the surface and the body.
        texCoord0 = (uv0 + d * b + c) / size; // 2. Expand UV coordinates to match texture.
        t = d + (d * (b - e) * 2 / area) + f; // 3. Remove the overhang with a fragment shader.
    }
#endif
// default

}
