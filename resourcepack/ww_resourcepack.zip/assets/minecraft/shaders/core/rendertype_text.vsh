#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

// new
vec2[] corners = vec2[](
  vec2(0.0, 1.0),
  vec2(0.0, 0.0),
  vec2(1.0, 0.0),
  vec2(1.0, 1.0)
);

vec3 newPosition = Position;
// default

void main() {
    // new
    float id = floor((newPosition.y + 1000.0) / 2000.0);
    newPosition.y = mod(newPosition.y + 1000.0, 2000.0) - 1000.0;

    // modified
    gl_Position = ProjMat * ModelViewMat * vec4(newPosition, 1.0);

    // new
    bool marker = (Color.r == Color.g && Color.g == Color.b
        && Color.r * 255 < 255 && Color.r * 255 > 252);
    if (marker) {
        int corner = 255 - int(Color.r * 255);
        // top right
        if (corner == 1) {
            gl_Position.xy += gl_Position.w * vec2(1,2);
        }
        // top left
        else if (corner == 2) {
            gl_Position.xy += gl_Position.w * vec2(-1,2);
        }
    }
    vertexColor = texelFetch(Sampler2, UV2 / 16, 0);
    if (!marker)
        vertexColor *= Color;
    else {
        vertexColor *= vec4(1);
    }
    if (id >= 4.0 && id <= 5.0) {
        vec2 corner = corners[gl_VertexID % 4];
        vec2 scaled = (corner * 2.0 - 1.0);

        gl_Position = vec4(scaled, 0.0, 1.0);
    }
    // default

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    texCoord0 = UV0;
}
