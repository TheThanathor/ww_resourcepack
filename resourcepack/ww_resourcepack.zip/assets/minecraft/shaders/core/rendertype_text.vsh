#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float offsets[9] = float[9](
    -2.0,
    -1.5,
    -1.0,
    -0.5,
     0.0,
     0.5,
     1.0,
     1.5,
     2.0
);

void main() {

    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    // new
    bool marker = (Color.r == Color.g && Color.g == Color.b
        && Color.r * 255 < 255 && Color.r * 255 > 252);
    if (marker) {
        int corner = 255 - int(Color.r * 255);
        // top right
        if (corner == 1) {
            gl_Position.xy += gl_Position.w * vec2(1,2);
        }
        // top left
        else if (corner == 2) {
            gl_Position.xy += gl_Position.w * vec2(-1,2);
        }
    }
    // default

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    // new
    vertexColor = texelFetch(Sampler2, UV2 / 16, 0);
    if (!marker)
        vertexColor *= Color;
    else {
        vertexColor *= vec4(1);
    }
    // default
    texCoord0 = UV0;
}
